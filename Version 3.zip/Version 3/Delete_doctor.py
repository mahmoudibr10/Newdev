from cgitb import text
from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox
import mysql.connector
from doctor import *


def deletedoctor():

    doctor_ID = doctor_IDs.get()

    conn = mysql.connector.connect(host="localhost",
                                   user="root",
                                   password="#insert your sql password",
                                   database="Hospital")

    doctorinfo = "Delete from doctor where patient_ID = %s"
    val = doctor_ID
    try:
        cursory = conn.cursor()
        cursory.execute(doctorinfo, (val,))
        conn.commit()
        messagebox.showinfo('Success')
    except:
        messagebox.showinfo("Error")
        conn.rollback()


def delete_doctor():
    global doctor_IDs, Canvas1, conn, cursory, doctor, root
    window = Tk()
    window.title("Hospital")
    window.minsize(width=800, height=800)
    window.geometry("800x800")

    conn = mysql.connector.connect(host="localhost",
                                   user="root",
                                   password="#insert your sql password",
                                   database="Hospital")
    cursory = conn.cursor()

    # Enter Table Names here
    doctor = "doctor"  # Book Table

    Canvas1 = Canvas(window)

    Canvas1.config(bg="#00FFFF")
    Canvas1.pack(expand=True, fill=BOTH)

    headingFrame1 = Frame(window, bg="#FFBB00", bd=5)
    headingFrame1.place(relx=0.25, rely=0.1, relwidth=0.5, relheight=0.13)

    headingLabel = Label(headingFrame1, text="Delete patient",
                         bg='black', fg='white', font=('Courier', 15))
    headingLabel.place(relx=0, rely=0, relwidth=1, relheight=1)

    labelFrame = Frame(window, bg='black')
    labelFrame.place(relx=0.1, rely=0.3, relwidth=0.8, relheight=0.5)

    # patient ID
    lb1 = Label(labelFrame, text=" Enter Patient ID : ",
                bg='black', fg='white')
    lb1.place(relx=0.05, rely=0.5, relheight=0.03)

    patient_IDs = Entry(labelFrame)
    patient_IDs.place(relx=0.3, rely=0.5, relwidth=0.62, relheight=0.03)

    SubmitBtn = Button(window, text="SUBMIT", bg='#d1ccc0',
                       fg='black', command=deletedoctor)
    SubmitBtn.place(relx=0.28, rely=0.9, relwidth=0.18, relheight=0.08)

    quitBtn = Button(window, text="Quit", bg='#f7f1e3',
                     fg='black',       command=window.destroy)
    quitBtn.place(relx=0.53, rely=0.9, relwidth=0.18, relheight=0.08)
    window.mainloop()
