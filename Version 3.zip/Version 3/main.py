from tkinter import *
from PIL import ImageTk, Image  # PIL -> Pillow
import pymysql
from tkinter import messagebox
from Patients import *
from Doctormain import *


mypass = "#insert your sql password"  # use your own password
mydatabase = "Hospital"  # The database name
con = pymysql.connect(host="localhost", user="root",
                      password=mypass, database=mydatabase)
# root is the username here

# Creating Tkinter window
cur = con.cursor()  # cur -> cursor
window = Tk()
window.title("Hospital")
window.minsize(width=400, height=400)
window.geometry("700x700")

# Adding header to window
headingFrame1 = Frame(window, bg="#FFBB00", bd=5)
headingFrame1.place(relx=0.2, rely=0.1, relwidth=0.6, relheight=0.16)
headingLabel = Label(headingFrame1, text="Welcome To \n NU Hospital",
                     bg='black', fg='white', font=('Courier', 15))
headingLabel.place(relx=0, rely=0, relwidth=1, relheight=1)

# Adding buttons to go to new window
btn1 = Button(window, text="Patients", bg='black',
              fg='white', command=patientmain)
btn1.place(relx=0.28, rely=0.4, relwidth=0.45, relheight=0.1)

btn2 = Button(window, text="Doctors", bg='black',
              fg='white', command=doctormain)
btn2.place(relx=0.28, rely=0.5, relwidth=0.45, relheight=0.1)

btn3 = Button(window, text="Nurses", bg='black', fg='white')
btn3.place(relx=0.28, rely=0.6, relwidth=0.45, relheight=0.1)

btn4 = Button(window, text="Rooms", bg='black', fg='white')
btn4.place(relx=0.28, rely=0.7, relwidth=0.45, relheight=0.1)


window.mainloop()
