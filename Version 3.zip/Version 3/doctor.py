from cgitb import text
from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox
import mysql.connector


def doctorRegister():

    # Connecting to database
    # Linking Python with Sql
    fname = doctorname1.get()
    lname_ = doctorname2.get()
    age_ = ages.get()
    gender_ = genders.get()
    phone_number_ = phone_numbers.get()
    doctor_ID_ = doctor_IDs.get()
    speciality_ = specialitys.get()
    address_ = addresss.get()

    conn = mysql.connector.connect(host="localhost",
                                   user="root",
                                   password="#insert your sql password",
                                   database="Hospital")
    doctorinfo = "INSERT INTO doctor(fname, lname,age,gender,phone_number,doctor_ID,speciality,address)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"
    val = (fname, lname_, age_, gender_, phone_number_,
           doctor_ID_, speciality_, address_)
    try:
        cursory = conn.cursor()
        cursory.execute(doctorinfo, val)
        conn.commit()
        messagebox.showinfo('Success')
    except:
        messagebox.showinfo("Error")
        conn.rollback()

    print(fname)
    print(lname_)
    print(age_)
    print(gender_)
    print(phone_number_)
    print(doctor_ID_)
    print(speciality_)
    print(address_)


def doctors():
    # Deffining global variable
    global doctorname1, doctorname2, ages, genders, phone_numbers, doctor_IDs, specialitys, addresss, Canvas1, conn, cursory, doctor, root
    window = Tk()
    window.title("Hospital")
    window.minsize(width=800, height=800)
    window.geometry("800x800")
    conn = mysql.connector.connect(host="localhost",
                                   user="root",
                                   password="#insert your sql password",
                                   database="Hospital")
    cursory = conn.cursor()

    # Enter Table Names here
    doctor = "doctor"  # Book Table

    Canvas1 = Canvas(window)

    Canvas1.config(bg="#00FFFF")
    Canvas1.pack(expand=True, fill=BOTH)

    # Customizing Header
    headingFrame1 = Frame(window, bg="#FFBB00", bd=5)
    headingFrame1.place(relx=0.25, rely=0.1, relwidth=0.5, relheight=0.13)

    headingLabel = Label(headingFrame1, text="Add doctor",
                         bg='black', fg='white', font=('Courier', 15))
    headingLabel.place(relx=0, rely=0, relwidth=1, relheight=1)

    labelFrame = Frame(window, bg='black')
    labelFrame.place(relx=0.1, rely=0.3, relwidth=0.8, relheight=0.5)

    # Firstname Button
    lb1 = Label(labelFrame, text=" First Name : ", bg='black', fg='white')
    lb1.place(relx=0.05, rely=0.11875, relheight=0.03)

    doctorname1 = Entry(labelFrame)
    doctorname1.place(relx=0.3, rely=0.11875, relwidth=0.62, relheight=0.03)

    # Lastname Button
    lb2 = Label(labelFrame, text=" Second Name : ", bg='black', fg='white')
    lb2.place(relx=0.05, rely=0.2375, relheight=0.03)

    doctorname2 = Entry(labelFrame)
    doctorname2.place(relx=0.3, rely=0.2375, relwidth=0.62, relheight=0.03)

    # Age Button
    lb3 = Label(labelFrame, text="Age : ", bg='black', fg='white')
    lb3.place(relx=0.05, rely=0.35625, relheight=0.03)

    ages = Entry(labelFrame)
    ages.place(relx=0.3, rely=0.35625, relwidth=0.62, relheight=0.03)

    # Gender Button
    lb4 = Label(labelFrame, text="Gender : ", bg='black', fg='white')
    lb4.place(relx=0.05, rely=0.475, relheight=0.08)

    genders = Entry(labelFrame)
    genders.place(relx=0.3, rely=0.475, relwidth=0.62, relheight=0.03)

    # Phone no. Button
    lb5 = Label(labelFrame, text="Phone Number : ", bg='black', fg='white')
    lb5.place(relx=0.05, rely=0.59375, relheight=0.03)

    phone_numbers = Entry(labelFrame)
    phone_numbers.place(relx=0.3, rely=0.59375, relwidth=0.62, relheight=0.03)

    # Doctor ID Button
    lb6 = Label(labelFrame, text="doctor ID : ", bg='black', fg='white')
    lb6.place(relx=0.05, rely=0.7125, relheight=0.03)

    doctor_IDs = Entry(labelFrame)
    doctor_IDs.place(relx=0.3, rely=0.7125, relwidth=0.62, relheight=0.03)

    # Disease Button
    lb7 = Label(labelFrame, text="speciality : ", bg='black', fg='white')
    lb7.place(relx=0.05, rely=0.83125, relheight=0.03)

    specialitys = Entry(labelFrame)
    specialitys.place(relx=0.3, rely=0.83125, relwidth=0.62, relheight=0.03)

    # Address Button
    lb8 = Label(labelFrame, text="Address : ", bg='black', fg='white')
    lb8.place(relx=0.05, rely=0.95, relheight=0.03)

    addresss = Entry(labelFrame)
    addresss.place(relx=0.3, rely=0.95, relwidth=0.62, relheight=0.03)

    # Submit Button
    SubmitBtn = Button(window, text="SUBMIT", bg='#d1ccc0',
                       fg='black', command=doctorRegister)
    SubmitBtn.place(relx=0.28, rely=0.9, relwidth=0.18, relheight=0.08)

    quitBtn = Button(window, text="Quit", bg='#f7f1e3',
                     fg='black',       command=window.destroy)
    quitBtn.place(relx=0.53, rely=0.9, relwidth=0.18, relheight=0.08)

    window.mainloop()
