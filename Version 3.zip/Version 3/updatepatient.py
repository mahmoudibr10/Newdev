from cgitb import text
from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox
import mysql.connector


def updatepatient():

    # Connecting to database
    # Linking Python with Sql
    fname = patientname1.get()
    lname_ = patientname2.get()
    age_ = ages.get()
    gender_ = genders.get()
    phone_number_ = phone_numbers.get()
    patient_ID_ = patient_IDs.get()
    disease_ = diseases.get()
    address_ = addresss.get()

    conn = mysql.connector.connect(host="localhost",
                                   user="root",
                                   password="#insert your sql password",
                                   database="Hospital")
    patientinfo = """Update patient where patient_ID= set fname=%s set lname=%s set age=%s set gender=%s set phone_number=%s set patient_ID=%s set disease=%s set address=%s)"""
    val = (fname, lname_, age_, gender_, phone_number_,
           patient_ID_, disease_, address_)
    try:
        cursory = conn.cursor()
        cursory.execute(patientinfo, val)
        conn.commit()
        messagebox.showinfo('Success')
    except:
        messagebox.showinfo("Error")
        conn.rollback()

    print(fname)
    print(lname_)
    print(age_)
    print(gender_)
    print(phone_number_)
    print(patient_ID_)
    print(disease_)
    print(address_)


def update():

    # Creating tkinter window
    window = Tk()
    window.title("Hospital")
    window.minsize(width=800, height=800)
    window.geometry("800x800")

    conn = mysql.connector.connect(host="localhost",
                                   user="root",
                                   password="#insert your sql password",
                                   database="Hospital")
    cursory = conn.cursor()

    # Enter Table Names here
    patient = "patient"  # Book Table

    Canvas1 = Canvas(window)

    Canvas1.config(bg="#00FFFF")
    Canvas1.pack(expand=True, fill=BOTH)

    headingFrame1 = Frame(window, bg="#00008B", bd=9)
    headingFrame1.place(relx=0.25, rely=0.1, relwidth=0.5, relheight=0.13)

    headingLabel = Label(headingFrame1, text="edit patient",
                         bg='black', fg='white', font=('Courier', 15))
    headingLabel.place(relx=0, rely=0, relwidth=1, relheight=1)

    labelFrame = Frame(window, bg='black')
    labelFrame.place(relx=0.1, rely=0.3, relwidth=0.8, relheight=0.5)

    # patient ID
    lb1 = Label(labelFrame, text=" Enter Patient ID : ",
                bg='black', fg='white')
    lb1.place(relx=0.05, rely=0.5, relheight=0.03)

    patient_ID_edit = Entry(labelFrame)
    patient_ID_edit.place(relx=0.3, rely=0.5, relwidth=0.62, relheight=0.03)

    SubmitBtn = Button(window, text="SUBMIT", bg='#d1ccc0',
                       fg='black', command=update_patient)
    SubmitBtn.place(relx=0.28, rely=0.9, relwidth=0.18, relheight=0.08)
    window.mainloop()


def update_patient():
    global patientname1, patientname2, ages, genders, phone_numbers, patient_IDs, diseases, addresss, Canvas1, conn, cursory, patient, root
    window = Tk()
    window.title("Hospital")
    window.minsize(width=800, height=800)
    window.geometry("800x800")

    conn = mysql.connector.connect(host="localhost",
                                   user="root",
                                   password="#insert your sql password",
                                   database="Hospital")
    cursory = conn.cursor()

    # Enter Table Names here
    patient = "patient"  # Book Table

    Canvas1 = Canvas(window)

    Canvas1.config(bg="#00FFFF")
    Canvas1.pack(expand=True, fill=BOTH)

    headingFrame1 = Frame(window, bg="#FFBB00", bd=5)
    headingFrame1.place(relx=0.25, rely=0.1, relwidth=0.5, relheight=0.13)

    headingLabel = Label(headingFrame1, text="Edit Patient",
                         bg='black', fg='white', font=('Courier', 15))
    headingLabel.place(relx=0, rely=0, relwidth=1, relheight=1)

    labelFrame = Frame(window, bg='black')
    labelFrame.place(relx=0.1, rely=0.3, relwidth=0.8, relheight=0.5)

    # Firstname button
    lb1 = Label(labelFrame, text=" First Name : ", bg='black', fg='white')
    lb1.place(relx=0.05, rely=0.125, relheight=0.03)

    patientname1 = Entry(labelFrame)
    patientname1.place(relx=0.3, rely=0.125, relwidth=0.62, relheight=0.03)

    # Secondname button
    lb2 = Label(labelFrame, text=" Second Name : ", bg='black', fg='white')
    lb2.place(relx=0.05, rely=0.25, relheight=0.03)

    patientname2 = Entry(labelFrame)
    patientname2.place(relx=0.3, rely=0.25, relwidth=0.62, relheight=0.03)

    # Age button
    lb3 = Label(labelFrame, text="Age : ", bg='black', fg='white')
    lb3.place(relx=0.05, rely=0.375, relheight=0.03)

    ages = Entry(labelFrame)
    ages.place(relx=0.3, rely=0.375, relwidth=0.62, relheight=0.03)

    # Gender Button
    lb4 = Label(labelFrame, text="Gender : ", bg='black', fg='white')
    lb4.place(relx=0.05, rely=0.5, relheight=0.08)

    genders = Entry(labelFrame)
    genders.place(relx=0.3, rely=0.5, relwidth=0.62, relheight=0.03)

    # Phone no. button
    lb5 = Label(labelFrame, text="Phone Number : ", bg='black', fg='white')
    lb5.place(relx=0.05, rely=0.625, relheight=0.03)

    phone_numbers = Entry(labelFrame)
    phone_numbers.place(relx=0.3, rely=0.625, relwidth=0.62, relheight=0.03)

    # Patient ID button
    lb6 = Label(labelFrame, text="Patient ID : ", bg='black', fg='white')
    lb6.place(relx=0.05, rely=0.75, relheight=0.03)

    patient_IDs = Entry(labelFrame)
    patient_IDs.place(relx=0.3, rely=0.75, relwidth=0.62, relheight=0.03)

    # Disease Button
    lb7 = Label(labelFrame, text="Disease : ", bg='black', fg='white')
    lb7.place(relx=0.05, rely=0.875, relheight=0.03)

    diseases = Entry(labelFrame)
    diseases.place(relx=0.3, rely=0.875, relwidth=0.62, relheight=0.03)

    # Address button
    lb8 = Label(labelFrame, text="Address : ", bg='black', fg='white')
    lb8.place(relx=0.05, rely=0.925, relheight=0.03)

    addresss = Entry(labelFrame)
    addresss.place(relx=0.3, rely=0.925, relwidth=0.62, relheight=0.03)

    # Submit Button
    SubmitBtn = Button(window, text="SUBMIT", bg='#d1ccc0',
                       fg='black', command=updatepatient)
    SubmitBtn.place(relx=0.28, rely=0.9, relwidth=0.18, relheight=0.08)

    quitBtn = Button(window, text="Quit", bg='#f7f1e3',
                     fg='black',       command=window.destroy)
    quitBtn.place(relx=0.53, rely=0.9, relwidth=0.18, relheight=0.08)
