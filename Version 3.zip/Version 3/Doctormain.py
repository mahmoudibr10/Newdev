from tkinter import *
from PIL import ImageTk, Image  # PIL -> Pillow
import pymysql
from tkinter import messagebox
from Updatedoctor import *
from doctor import *
from view_doctor import *
from Delete_doctor import *


def doctormain():

    # Connecting to database
    # Linking Python with Sql
    mypass = "#insert your sql password"  # use your own password
    mydatabase = "Hospital"  # The database name
    con = pymysql.connect(host="localhost", user="root",
                          password=mypass, database=mydatabase)
    # root is the username here
    cur = con.cursor()  # cur -> cursor
    window = Tk()
    window.title("Hopital")
    window.minsize(width=400, height=400)
    window.geometry("600x500")

    # Adding a header
    headingFrame1 = Frame(window, bg="#FFBB00", bd=5)
    headingFrame1.place(relx=0.2, rely=0.1, relwidth=0.6, relheight=0.16)
    headingLabel = Label(headingFrame1, text="Welcome to \n NU Hospital",
                         bg='black', fg='white', font=('Courier', 15))
    headingLabel.place(relx=0, rely=0, relwidth=1, relheight=1)

    # Adding functional buttons
    btn1 = Button(window, text="Add Doctor", bg='black',
                  fg='white', command=doctors)
    btn1.place(relx=0.28, rely=0.4, relwidth=0.45, relheight=0.1)

    btn2 = Button(window, text="Delete Doctor", bg='black',
                  fg='white', command=delete_doctor)
    btn2.place(relx=0.28, rely=0.5, relwidth=0.45, relheight=0.1)

    btn3 = Button(window, text="View Doctor", bg='black',
                  fg='white', command=ViewDoctors)
    btn3.place(relx=0.28, rely=0.6, relwidth=0.45, relheight=0.1)

    btn4 = Button(window, text="Edit Doctor", bg='black',
                  fg='white', command=update_doctor)
    btn4.place(relx=0.28, rely=0.7, relwidth=0.45, relheight=0.1)

    window.mainloop()
