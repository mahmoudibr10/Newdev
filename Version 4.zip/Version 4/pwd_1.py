from tkinter import *
from tkinter import Entry
from tkinter import messagebox


def pwd_window():
    def login():
        pwd = password_entry.get()
        return pwd
    # Creating Tkinter window
    window = Tk()
    window.title("SQL Password")
    # window.minsize(width=250, height=100)
    window.geometry("340x140")
    window.configure(bg='#333333')

    frame = Frame(bg='#333333')

    # Creating widgets
    login_label = Label(frame, text='Insert Your SQL Password',
                        bg='#333333', fg="#ecb0e1", font=("Arial", 14))

    # Password Lable
    password_label = Label(frame, text="Password",
                           bg='#333333', fg="#FFFFFF", font=("Arial", 12))
    password_entry = Entry(frame, show="*", font=("Arial", 12))

    # Button
    login_button = Button(frame, text="Login", bg="#ecb0e1",
                          fg="#000000", font=("Arial", 12), command=login)

    # Placing widgets on the screen
    login_label.grid(row=0, column=0, columnspan=2,
                     sticky="news", pady="20")
    password_label.grid(row=1, column=0)
    password_entry.grid(row=1, column=1)
    login_button.grid(row=2, column=0, columnspan=2, pady="10")

    frame.pack()

    window.mainloop()


pwd_window()
