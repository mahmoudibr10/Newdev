-- create database Hospital;

use Hospital;
create table patient (
fname varchar (50) NOT NULL,
lname varchar(50) NOT NULL,
age int NOT NULL,
gender varchar(50) NOT NULL,
phone_number int NOT NULL,
patient_ID int NOT NULL,
disease varchar(50) NOT NULL,
address varchar(50) not null,
primary key(patient_ID)
);	
select * from patient;
alter table doctor
drop Room_no;
create table doctor (
fname varchar (50) NOT NULL,
lname varchar(50) NOT NULL,
age int NOT NULL,
gender varchar(50) NOT NULL,
phone_number int NOT NULL,
doctor_ID int NOT NULL,
address varchar(50) not null,
location varchar(50) not null,
primary key(Doctor_ID)
);
select * from doctor;

create table bill(
bill_no int not null ,
fname varchar(50) not null,
primary key(bill_no)
);
select * from bill;
create table Room(
Room_no int not null,
Room_floor int not null,
primary key (Room_no));
alter table Room
add occupied bit;
select * from Room;
create table departments(
department_name varchar(50) not null,
Doctor varchar(50) not null,
patient varchar(50) not null,
nurse varchar(50) not null,
room int not null,
primary key (department_name)
);


alter table patient 
add column Room_no int;

alter table patient 
add foreign key (Room_no)
REFERENCES Room(Room_no);

alter table patient 
add column doctor_ID int;

alter table patient 
add foreign key (doctor_ID )
REFERENCES doctor(doctor_ID);

alter table patient 
add column bill_no int;

alter table patient 
add foreign key (bill_no)
REFERENCES bill(bill_no);

alter table patient 
add column Room_no int;

alter table patient 
add foreign key (Room_no)
REFERENCES Room(Room_no);

alter table patient 
add column nurse_ID int;

alter table patient 
add foreign key (nurse_ID)
REFERENCES nurse(nurse_ID);


alter table departments
add column nurse_ID int,
add column doctor_ID int,
add column patient_ID int,
add column Room_no int;


alter table departments
add foreign key (nurse_ID)
REFERENCES nurse(nurse_ID);


alter table departments
add foreign key (doctor_ID)
REFERENCES doctor (doctor_ID);

alter table departments
add foreign key (patient_ID)
REFERENCES patient(patient_ID);


alter table departments
add foreign key (Room_no)
REFERENCES Room(Room_no);


create table depBridge(
nurse_ID int,
department_name varchar(50)
);


alter table depBridge
add foreign key (nurse_ID)
REFERENCES nurse(nurse_ID);


alter table depBridge
add foreign key (department_name)
REFERENCES departments(department_name);


create table depdoc(
doctor_ID int,
department_name varchar(50)
);

alter table depdoc
add foreign key (doctor_ID)
REFERENCES doctor(doctor_ID);

alter table depdoc
add foreign key (department_name)
REFERENCES departments(department_name);

select * from departments
