from cgitb import text
from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox
import mysql.connector


def updatedoctor():

    # Connecting to database
    # Linking Python with Sql
    fname = doctorname1.get()
    lname = doctorname2.get()
    age = ages.get()
    gender = genders.get()
    phone_number = phone_numbers.get()
    doctor_ID = doctor_IDs.get()
    address = address.get()
    speciality = specialitys.get()

    conn = mysql.connector.connect(host="localhost",
                                   user="root",
                                   password="Insert Your SQL Password",
                                   database="Hospital")
    patientinfo = """Update patient set fname=%s set lname=%s set age=%s set gender=%s set phone_number=%s set patient_ID=%s set disease=%s set address=%s)"""
    val = (fname, lname, age, gender, phone_number,
           doctor_ID, speciality, address)

    #
    try:
        cursory = conn.cursor()
        cursory.execute(patientinfo, val)
        conn.commit()
        messagebox.showinfo('Success')
    except:
        messagebox.showinfo("Error")
        conn.rollback()


def update_doctor():
    global doctorname1, doctorname2, ages, genders, genders, phone_numbers, doctor_IDs, specialitys, addresss, Canvas1, con, cur, doctor, root
    window = Tk()
    window.title("Hospital")
    window.minsize(width=800, height=800)
    window.geometry("800x800")

    conn = mysql.connector.connect(host="localhost",
                                   user="root",
                                   password="Insert Your SQL Password",
                                   database="Hospital")
    cursory = conn.cursor()

    # Enter Table Names here
    doctor = "doctor"  # Book Table

    Canvas1 = Canvas(window)

    Canvas1.config(bg="#00FFFF")
    Canvas1.pack(expand=True, fill=BOTH)

    headingFrame1 = Frame(window, bg="#FFBB00", bd=5)
    headingFrame1.place(relx=0.25, rely=0.1, relwidth=0.5, relheight=0.13)

    headingLabel = Label(headingFrame1, text="Edit Doctor",
                         bg='black', fg='white', font=('Courier', 15))
    headingLabel.place(relx=0, rely=0, relwidth=1, relheight=1)

    labelFrame = Frame(window, bg='black')
    labelFrame.place(relx=0.1, rely=0.3, relwidth=0.8, relheight=0.5)

    # patient ID
    lb1 = Label(labelFrame, text=" First Name : ", bg='black', fg='white')
    lb1.place(relx=0.05, rely=0.11875, relheight=0.03)

    doctorname1 = Entry(labelFrame)
    doctorname1.place(relx=0.3, rely=0.11875, relwidth=0.62, relheight=0.03)
    # firstname
    lb2 = Label(labelFrame, text=" Second Name : ", bg='black', fg='white')
    lb2.place(relx=0.05, rely=0.2375, relheight=0.03)

    doctorname2 = Entry(labelFrame)
    doctorname2.place(relx=0.3, rely=0.2375, relwidth=0.62, relheight=0.03)
    # lastname
    lb3 = Label(labelFrame, text="Age : ", bg='black', fg='white')
    lb3.place(relx=0.05, rely=0.35625, relheight=0.03)

    ages = Entry(labelFrame)
    ages.place(relx=0.3, rely=0.35625, relwidth=0.62, relheight=0.03)

    # gender
    lb4 = Label(labelFrame, text="Gender : ", bg='black', fg='white')
    lb4.place(relx=0.05, rely=0.475, relheight=0.08)

    genders = Entry(labelFrame)
    genders.place(relx=0.3, rely=0.475, relwidth=0.62, relheight=0.03)

    # age
    lb5 = Label(labelFrame, text="Phone Number : ", bg='black', fg='white')
    lb5.place(relx=0.05, rely=0.59375, relheight=0.03)

    phone_numbers = Entry(labelFrame)
    phone_numbers.place(relx=0.3, rely=0.59375, relwidth=0.62, relheight=0.03)
    # phone no.
    lb6 = Label(labelFrame, text="Doctor ID : ", bg='black', fg='white')
    lb6.place(relx=0.05, rely=0.7125, relheight=0.03)

    doctor_IDs = Entry(labelFrame)
    doctor_IDs.place(relx=0.3, rely=0.7125, relwidth=0.62, relheight=0.03)
    # disease
    lb7 = Label(labelFrame, text="Disease : ", bg='black', fg='white')
    lb7.place(relx=0.05, rely=0.83125, relheight=0.03)

    speciality = Entry(labelFrame)
    speciality.place(relx=0.3, rely=0.83125, relwidth=0.62, relheight=0.03)
    # address
    lb8 = Label(labelFrame, text="Address : ", bg='black', fg='white')
    lb8.place(relx=0.05, rely=0.95, relheight=0.03)

    addresss = Entry(labelFrame)
    addresss.place(relx=0.3, rely=0.95, relwidth=0.62, relheight=0.03)

    # Submit Button
    SubmitBtn = Button(window, text="SUBMIT", bg='#d1ccc0',
                       fg='black', command=updatedoctor)
    SubmitBtn.place(relx=0.28, rely=0.9, relwidth=0.18, relheight=0.08)

    quitBtn = Button(window, text="Quit", bg='#f7f1e3',
                     fg='black',       command=window.destroy)
    quitBtn.place(relx=0.53, rely=0.9, relwidth=0.18, relheight=0.08)

    window.mainloop()
