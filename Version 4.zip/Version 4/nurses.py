from cgitb import text
from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox
import mysql.connector


def nurseRegister():
    fname = nursename1.get()
    lname_ = nursename2.get()
    age_ = ages.get()
    gender_ = genders.get()
    phone_number_ = phone_numbers.get()
    nurse_ID_ = nurse_IDs.get()
    address_ = addresss.get()
    location = locations.get()
    conn = mysql.connector.connect(host="localhost",
                                   user="root",
                                   password="Insert Your SQL Password",
                                   database="Hospital")
    nurseinfo = "INSERT INTO nurse (fname, lname,age,gender,phone_number,nurse_ID,location,address)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"
    val = (fname, lname_, age_, gender_, phone_number_,
           nurse_ID_, location, address_)
    try:
        cursory = conn.cursor()
        cursory.execute(nurseinfo, val)
        conn.commit()
        messagebox.showinfo('Success')
    except:
        messagebox.showinfo("Error")


def nurses():
    global nursename1, nursename2, ages, genders, phone_numbers, nurse_IDs, addresss, Canvas1, locations, conn, cursory, nurse, root
    window = Tk()
    window.title("Hospital")
    window.minsize(width=800, height=800)
    window.geometry("800x800")
    conn = mysql.connector.connect(host="localhost",
                                   user="root",
                                   password="Insert Your SQL Password",
                                   database="Hospital")
    cursory = conn.cursor()

    # Enter Table Names here
    nurse = "nurse"  # Book Table

    Canvas1 = Canvas(window)

    Canvas1.config(bg="#00FFFF")
    Canvas1.pack(expand=True, fill=BOTH)

    headingFrame1 = Frame(window, bg="#FFBB00", bd=5)
    headingFrame1.place(relx=0.25, rely=0.1, relwidth=0.5, relheight=0.13)

    headingLabel = Label(headingFrame1, text="Add nurse",
                         bg='black', fg='white', font=('Courier', 15))
    headingLabel.place(relx=0, rely=0, relwidth=1, relheight=1)

    labelFrame = Frame(window, bg='black')
    labelFrame.place(relx=0.1, rely=0.3, relwidth=0.8, relheight=0.5)

    # firstname
    lb1 = Label(labelFrame, text=" First Name : ", bg='black', fg='white')
    lb1.place(relx=0.05, rely=0.11875, relheight=0.03)

    nursename1 = Entry(labelFrame)
    nursename1.place(relx=0.3, rely=0.11875, relwidth=0.62, relheight=0.03)

    # lastname
    lb2 = Label(labelFrame, text=" Second Name : ", bg='black', fg='white')
    lb2.place(relx=0.05, rely=0.2375, relheight=0.03)

    nursename2 = Entry(labelFrame)
    nursename2.place(relx=0.3, rely=0.2375, relwidth=0.62, relheight=0.03)
    # Age
    lb3 = Label(labelFrame, text="Age : ", bg='black', fg='white')
    lb3.place(relx=0.05, rely=0.35625, relheight=0.03)

    ages = Entry(labelFrame)
    ages.place(relx=0.3, rely=0.35625, relwidth=0.62, relheight=0.03)

    # Gender
    lb4 = Label(labelFrame, text="Gender : ", bg='black', fg='white')
    lb4.place(relx=0.05, rely=0.475, relheight=0.08)

    genders = Entry(labelFrame)
    genders.place(relx=0.3, rely=0.475, relwidth=0.62, relheight=0.03)

    # Phone Number
    lb5 = Label(labelFrame, text="Phone Number : ", bg='black', fg='white')
    lb5.place(relx=0.05, rely=0.59375, relheight=0.03)

    phone_numbers = Entry(labelFrame)
    phone_numbers.place(relx=0.3, rely=0.59375, relwidth=0.62, relheight=0.03)
    # phone no.
    lb6 = Label(labelFrame, text="nurse ID : ", bg='black', fg='white')
    lb6.place(relx=0.05, rely=0.7125, relheight=0.03)

    # Nurse ID
    nurse_IDs = Entry(labelFrame)
    nurse_IDs.place(relx=0.3, rely=0.7125, relwidth=0.62, relheight=0.03)

    # Address
    lb7 = Label(labelFrame, text="Address : ", bg='black', fg='white')
    lb7.place(relx=0.05, rely=0.83125, relheight=0.03)

    addresss = Entry(labelFrame)
    addresss.place(relx=0.3, rely=0.83125, relwidth=0.62, relheight=0.03)

    lb8 = Label(labelFrame, text="Address : ", bg='black', fg='white')
    lb8.place(relx=0.05, rely=0.83125, relheight=0.03)

    locations = Entry(labelFrame)
    locations.place(relx=0.3, rely=0.83125, relwidth=0.62, relheight=0.03)

    # Submit Button
    SubmitBtn = Button(window, text="SUBMIT", bg='#d1ccc0',
                       fg='black', command=nurseRegister)
    SubmitBtn.place(relx=0.28, rely=0.9, relwidth=0.18, relheight=0.08)

    quitBtn = Button(window, text="Quit", bg='#f7f1e3',
                     fg='black',       command=window.destroy)
    quitBtn.place(relx=0.53, rely=0.9, relwidth=0.18, relheight=0.08)

    window.mainloop()
