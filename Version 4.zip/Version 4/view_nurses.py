from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox
import pymysql
from nurses import *
mypass = "Insert Your SQL Password"
mydatabase = "Hospital"
con = pymysql.connect(host="localhost", user="root",
                      password=mypass, database=mydatabase)
cur = con.cursor()
# Enter Table Names here
nursetable = "nurse"


def Viewnurses():

    window = Tk()
    window.title("Hospital")
    window.minsize(width=400, height=400)
    window.geometry("800x800")
    Canvas1 = Canvas(window)
    Canvas1.config(bg="#12a4d9")
    Canvas1.pack(expand=True, fill=BOTH)
    headingFrame1 = Frame(window, bg="#FFBB00", bd=5)
    headingFrame1.place(relx=0.25, rely=0.1, relwidth=0.5, relheight=0.13)
    headingLabel = Label(headingFrame1, text="View Nurses",
                         bg='black', fg='white', font=('Courier', 15))
    headingLabel.place(relx=0, rely=0, relwidth=1, relheight=1)
    labelFrame = Frame(window, bg='black')
    labelFrame.place(relx=0.1, rely=0.3, relwidth=0.8, relheight=0.5)
    y = 0.25
    Label(labelFrame, text="%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s" % ('fname', 'lname', 'age', 'gender', 'phone_number', 'nurse_ID', 'location', 'address'),
          bg='black', fg='white').place(relx=0.01, rely=0.1)
    Label(labelFrame, text="--------------------------------------------------------------------------------------------------------------------------",
          bg='black', fg='white').place(relx=0.02, rely=0.2)
    getnurses = "select * from "+nursetable
    try:
        cur.execute(getnurses)
        con.commit()
        for i in cur:
            Label(labelFrame, text="%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s" %
                  (i[0], i[1], i[2], i[3], i[4], i[5], i[6], i[7]), bg='black', fg='white').place(relx=0.02, rely=y)
            y += 0.1
    except:
        messagebox.showinfo("Failed to fetch files from database")

    quitBtn = Button(window, text="Quit", bg='#f7f1e3',
                     fg='black', command=window.destroy)
    quitBtn.place(relx=0.4, rely=0.9, relwidth=0.18, relheight=0.08)

    window.mainloop()
