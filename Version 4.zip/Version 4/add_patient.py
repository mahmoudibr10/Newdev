from cgitb import text
from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox
import mysql.connector


def patientRegister():
    # Adding patient information to database
    print(patientname1.get())
    fname = patientname1.get()
    lname_ = patientname2.get()
    age_ = ages.get()
    gender_ = genders.get()
    phone_number_ = phone_numbers.get()
    patient_ID_ = patient_IDs.get()
    disease_ = diseases.get()
    address_ = addresss.get()

    # Linking Python with Sql
    conn = mysql.connector.connect(host="localhost",
                                   user="root",
                                   password="Insert Your SQL Password",
                                   database="Hospital")
    patientinfo = "INSERT INTO patient(fname, lname,age,gender,phone_number,patient_ID,disease, address)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"
    val = (fname, lname_, age_, gender_, phone_number_,
           patient_ID_, disease_, address_)

    # Showing a message to user if the data are added successfuly or not
    try:
        cursory = conn.cursor()
        cursory.execute(patientinfo, val)
        conn.commit()
        messagebox.showinfo('Success')
    except:
        messagebox.showinfo("Error")


def patients():
    # Deffining global variables
    # Creating Tkinter window
    global patientname1, patientname2, ages, genders, phone_numbers, patient_IDs, diseases, addresss, Canvas1, conn, cursory, patient, root
    window = Tk()
    window.title("Hospital")
    window.minsize(width=800, height=800)
    window.geometry("800x800")
    conn = mysql.connector.connect(host="localhost",
                                   user="root",
                                   password="Insert Your SQL Password",
                                   database="Hospital")
    cursory = conn.cursor()

    # Enter Table Names here
    patient = "patient"  # Book Table

    Canvas1 = Canvas(window)

    # Tkinter background color
    Canvas1.config(bg="#00FFFF")
    Canvas1.pack(expand=True, fill=BOTH)

    # Adding & customizing header to the window
    headingFrame1 = Frame(window, bg="#FFBB00", bd=5)
    headingFrame1.place(relx=0.25, rely=0.1, relwidth=0.5, relheight=0.13)

    headingLabel = Label(headingFrame1, text="Add Patient",
                         bg='black', fg='white', font=('Courier', 15))
    headingLabel.place(relx=0, rely=0, relwidth=1, relheight=1)

    labelFrame = Frame(window, bg='black')
    labelFrame.place(relx=0.1, rely=0.3, relwidth=0.8, relheight=0.5)

    # Firstname
    lb1 = Label(labelFrame, text=" First Name : ", bg='black', fg='white')
    lb1.place(relx=0.05, rely=0.11875, relheight=0.03)

    patientname1 = Entry(labelFrame)
    patientname1.place(relx=0.3, rely=0.11875, relwidth=0.62, relheight=0.03)

    # Lastname
    lb2 = Label(labelFrame, text=" Second Name : ", bg='black', fg='white')
    lb2.place(relx=0.05, rely=0.2375, relheight=0.03)

    patientname2 = Entry(labelFrame)
    patientname2.place(relx=0.3, rely=0.2375, relwidth=0.62, relheight=0.03)

    # Age
    lb3 = Label(labelFrame, text="Age : ", bg='black', fg='white')
    lb3.place(relx=0.05, rely=0.35625, relheight=0.03)

    ages = Entry(labelFrame)
    ages.place(relx=0.3, rely=0.35625, relwidth=0.62, relheight=0.03)

    # Gender
    lb4 = Label(labelFrame, text="Gender : ", bg='black', fg='white')
    lb4.place(relx=0.05, rely=0.475, relheight=0.08)

    genders = Entry(labelFrame)
    genders.place(relx=0.3, rely=0.475, relwidth=0.62, relheight=0.03)

    # Phone no.
    lb5 = Label(labelFrame, text="Phone Number : ", bg='black', fg='white')
    lb5.place(relx=0.05, rely=0.59375, relheight=0.03)

    phone_numbers = Entry(labelFrame)
    phone_numbers.place(relx=0.3, rely=0.59375, relwidth=0.62, relheight=0.03)

    # Patient ID
    lb6 = Label(labelFrame, text="Patient ID : ", bg='black', fg='white')
    lb6.place(relx=0.05, rely=0.7125, relheight=0.03)

    patient_IDs = Entry(labelFrame)
    patient_IDs.place(relx=0.3, rely=0.7125, relwidth=0.62, relheight=0.03)

    # Disease
    lb7 = Label(labelFrame, text="Disease : ", bg='black', fg='white')
    lb7.place(relx=0.05, rely=0.83125, relheight=0.03)

    diseases = Entry(labelFrame)
    diseases.place(relx=0.3, rely=0.83125, relwidth=0.62, relheight=0.03)

    # Address
    lb8 = Label(labelFrame, text="Address : ", bg='black', fg='white')
    lb8.place(relx=0.05, rely=0.95, relheight=0.03)

    addresss = Entry(labelFrame)
    addresss.place(relx=0.3, rely=0.95, relwidth=0.62, relheight=0.03)

    # Submit Button
    SubmitBtn = Button(window, text="SUBMIT", bg='#d1ccc0',
                       fg='black', command=patientRegister)
    SubmitBtn.place(relx=0.28, rely=0.9, relwidth=0.18, relheight=0.08)

    quitBtn = Button(window, text="Quit", bg='#f7f1e3',
                     fg='black',       command=window.destroy)
    quitBtn.place(relx=0.53, rely=0.9, relwidth=0.18, relheight=0.08)

    window.mainloop()
