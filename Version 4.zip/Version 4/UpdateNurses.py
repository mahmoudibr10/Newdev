from cgitb import text
from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox
import mysql.connector


def updatenurse():
    fname = nursename1.get()
    lname = nursename2.get()
    age = ages.get()
    gender = genders.get()
    phone_number = phone_numbers.get()
    nurse_ID = nurse_IDs.get()
    address = addresss.get()
    department = departments.get()

    conn = mysql.connector.connect(host="localhost",
                                   user="root",
                                   password="Insert Your SQL Password",
                                   database="Hospital")
    nurseinfo = """Update nurse set fname=%s set lname=%s set age=%s set gender=%s set phone_number=%s set patient_ID=%s set department=%s set address=%s)"""
    val = (fname, lname, age, gender, phone_number,
           nurse_ID, department, address)
    try:
        cursory = conn.cursor()
        cursory.execute(nurseinfo, val)
        conn.commit()
        messagebox.showinfo('Success')
    except:
        messagebox.showinfo("Error")
        conn.rollback()

    print(fname)
    print(lname)
    print(age)
    print(gender)
    print(phone_number)
    print(nurse_ID)
    print(department)
    print(address)


def update():
    window = Tk()
    window.title("Hospital")
    window.minsize(width=800, height=800)
    window.geometry("800x800")

    conn = mysql.connector.connect(host="localhost",
                                   user="root",
                                   password="Insert Your SQL Password",
                                   database="Hospital")
    cursory = conn.cursor()

    # Enter Table Names here
    nurse = "nurse"  # Book Table

    Canvas1 = Canvas(window)

    Canvas1.config(bg="#00FFFF")
    Canvas1.pack(expand=True, fill=BOTH)

    headingFrame1 = Frame(window, bg="#00008B", bd=9)
    headingFrame1.place(relx=0.25, rely=0.1, relwidth=0.5, relheight=0.13)

    headingLabel = Label(headingFrame1, text="edit nurse",
                         bg='black', fg='white', font=('Courier', 15))
    headingLabel.place(relx=0, rely=0, relwidth=1, relheight=1)

    labelFrame = Frame(window, bg='black')
    labelFrame.place(relx=0.1, rely=0.3, relwidth=0.8, relheight=0.5)

    # patient ID
    lb1 = Label(labelFrame, text=" Enter nurse ID : ", bg='black', fg='white')
    lb1.place(relx=0.05, rely=0.5, relheight=0.03)

    nurse_ID_edit = Entry(labelFrame)
    nurse_ID_edit.place(relx=0.3, rely=0.5, relwidth=0.62, relheight=0.03)

    SubmitBtn = Button(window, text="SUBMIT", bg='#d1ccc0',
                       fg='black', command=update_nurse)
    SubmitBtn.place(relx=0.28, rely=0.9, relwidth=0.18, relheight=0.08)
    window.mainloop()


def update_nurse():
    global nursename1, nursename2, ages, genders, genders, phone_numbers, nurse_IDs, departments, addresss, Canvas1, con, cur, nurse, root
    window = Tk()
    window.title("Hospital")
    window.minsize(width=800, height=800)
    window.geometry("800x800")

    conn = mysql.connector.connect(host="localhost",
                                   user="root",
                                   password="Insert Your SQL Password",
                                   database="Hospital")
    cursory = conn.cursor()

    # Enter Table Names here
    nurse = "nurse"  # Book Table

    Canvas1 = Canvas(window)

    Canvas1.config(bg="#00FFFF")
    Canvas1.pack(expand=True, fill=BOTH)

    headingFrame1 = Frame(window, bg="#FFBB00", bd=5)
    headingFrame1.place(relx=0.25, rely=0.1, relwidth=0.5, relheight=0.13)

    headingLabel = Label(headingFrame1, text="Edit nurse",
                         bg='black', fg='white', font=('Courier', 15))
    headingLabel.place(relx=0, rely=0, relwidth=1, relheight=1)

    labelFrame = Frame(window, bg='black')
    labelFrame.place(relx=0.1, rely=0.3, relwidth=0.8, relheight=0.5)

    # patient ID
    lb1 = Label(labelFrame, text=" First Name : ", bg='black', fg='white')
    lb1.place(relx=0.05, rely=0.11875, relheight=0.03)

    nursename1 = Entry(labelFrame)
    nursename1.place(relx=0.3, rely=0.11875, relwidth=0.62, relheight=0.03)
    # firstname
    lb2 = Label(labelFrame, text=" Second Name : ", bg='black', fg='white')
    lb2.place(relx=0.05, rely=0.2375, relheight=0.03)

    nursename2 = Entry(labelFrame)
    nursename2.place(relx=0.3, rely=0.2375, relwidth=0.62, relheight=0.03)
    # lastname
    lb3 = Label(labelFrame, text="Age : ", bg='black', fg='white')
    lb3.place(relx=0.05, rely=0.35625, relheight=0.03)

    ages = Entry(labelFrame)
    ages.place(relx=0.3, rely=0.35625, relwidth=0.62, relheight=0.03)

    # gender
    lb4 = Label(labelFrame, text="Gender : ", bg='black', fg='white')
    lb4.place(relx=0.05, rely=0.475, relheight=0.08)

    genders = Entry(labelFrame)
    genders.place(relx=0.3, rely=0.475, relwidth=0.62, relheight=0.03)

    # age
    lb5 = Label(labelFrame, text="Phone Number : ", bg='black', fg='white')
    lb5.place(relx=0.05, rely=0.59375, relheight=0.03)

    phone_numbers = Entry(labelFrame)
    phone_numbers.place(relx=0.3, rely=0.59375, relwidth=0.62, relheight=0.03)
    # phone no.
    lb6 = Label(labelFrame, text="Nurse ID : ", bg='black', fg='white')
    lb6.place(relx=0.05, rely=0.7125, relheight=0.03)

    nurse_IDs = Entry(labelFrame)
    nurse_IDs.place(relx=0.3, rely=0.7125, relwidth=0.62, relheight=0.03)
    # disease
    lb7 = Label(labelFrame, text="Department : ", bg='black', fg='white')
    lb7.place(relx=0.05, rely=0.83125, relheight=0.03)

    departments = Entry(labelFrame)
    departments.place(relx=0.3, rely=0.83125, relwidth=0.62, relheight=0.03)
    # address
    lb8 = Label(labelFrame, text="Address : ", bg='black', fg='white')
    lb8.place(relx=0.05, rely=0.95, relheight=0.03)

    addresss = Entry(labelFrame)
    addresss.place(relx=0.3, rely=0.95, relwidth=0.62, relheight=0.03)

    # Submit Button
    SubmitBtn = Button(window, text="SUBMIT", bg='#d1ccc0',
                       fg='black', command=updatenurse)
    SubmitBtn.place(relx=0.28, rely=0.9, relwidth=0.18, relheight=0.08)

    quitBtn = Button(window, text="Quit", bg='#f7f1e3',
                     fg='black',       command=window.destroy)
    quitBtn.place(relx=0.53, rely=0.9, relwidth=0.18, relheight=0.08)

    window.mainloop()
